from setuptools import setup, find_packages

setup(
    name='stringformatter0320',
    version='0.0.2',
    description='string formatter by eggSushi0320',
    author='eggSushi0320',
    author_email='astar5327z@gmail.com',
    url='https://github.com/lazarus0320/oss.git',
    install_requires=['',],
    packages=find_packages(exclude=[]),
    keywords=['stringformatter0320'],
    python_requires='>=3.6',
    package_data={},
    zip_safe=False,
    classifiers=[
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
)
